// app/sign-in/[[...sign-in]]/page.tsx
"use client";

import SignInForm from "../../components/sign-in";

export default function SignInPage() {
  return <SignInForm />;
}
