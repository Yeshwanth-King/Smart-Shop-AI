// app/generate/page.tsx

import GeneratedWebsite from "../components/genereate-website";

export default function GeneratePage() {
  return (
    <main>
      <GeneratedWebsite />
    </main>
  );
}
